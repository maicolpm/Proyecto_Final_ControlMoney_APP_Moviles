export const environment = {
    production: false,
    useEmulators: true,
    firebaseConfig: {
        apiKey: "AIzaSyAXtP7vu0mrPn00KKf8T4GLsdxa0mxDZ9k",
        authDomain: "test-3e5d9.firebaseapp.com",
        databaseURL: "https://test-3e5d9-default-rtdb.firebaseio.com",
        projectId: "test-3e5d9",
        storageBucket: "test-3e5d9.appspot.com",
        messagingSenderId: "149032591943",
        appId: "1:149032591943:web:153b20cd1871a7e6b38762"
    },
}